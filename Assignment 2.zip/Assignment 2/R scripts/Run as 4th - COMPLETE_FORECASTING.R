

################## SPLITTING DATA ON TEST AND TRAIN #########


install.packages("car")
library(car)
samp <- floor(0.75* nrow(matWeatherFinal))
samp
set.seed(123)
training.index <- sample(seq_len(nrow(matWeatherFinal)), size= samp)
train <- matWeatherFinal[training.index, ]
test <- matWeatherFinal[-training.index, ]


h<-matWeatherFinal
nrow(train)
na.omit(train)
#check sea level and temperature collinearity
#+Sea_Level_PressureIn

################## CHECKING FIT OF ALL THE BEST MODEL #########

lm.fit = lm(kWh ~ Temperature + month + day + `Day of Week` + hour,data=train) # removed peakhour and weekday #humidity is making a diff of 0.001
summary(lm.fit)

################### Getting all coefficients  #########
summary(lm.fit)$coefficients[,]

################### Getting 1 coefficient  #########
coef(summary(lm.fit))["month__02","Estimate"]
library("car")
vif(lm.fit)

pred=predict(lm.fit,test)
library("forecast")
accuracy(pred,train$kWh)

################## CHECKING FIT OF ALL THE VARIABLES #########

lm.fit1 = lm(power_ ~ ., data=train)
summary(lm.fit1)

pred=predict(lm.fit1,test)
accuracy(pred,train$power_)

#################### PREDICTING THE FORECAST#########################################


pred=predict(lm.fit,forecastPrediction)


class(forecastPrediction$month)
class(train$month)

class(forecastPrediction$`Day of Week`)
class(train$`Day of Week`)

Power.Prediction <- as.data.frame(pred)
View(Power.Prediction)


################ PLOTS BASED ON FITS ###############

plot(lm.fit)

################ CHECKING ACCURACY ###################

accuracy(lm.fit,forecastPrediction)










