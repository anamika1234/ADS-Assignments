install.packages("rpart.plot")
install.packages("rpart")
library(rpart)
library(rattle)


rt <- rpart(power_ ~ Temperature +  month__ +  day__ + hour__ +dayofWeek__ , data=train)
  
test.pred.rtree <- predict(rt,test) 


printcp(rt)
#rpart(formula = power_ ~ Temperature +  month__ +  day__ + hour__ +dayofWeek__ , data = train)

min.xerror <- rt$cptable[which.min(rt$cptable[,"xerror"]),"CP"]
min.xerror

rt.pruned <- prune(rt,cp = min.xerror) 

fancyRpartPlot(rt.pruned)





