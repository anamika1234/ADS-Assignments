forecastPrediction <- read.csv("forecastPrediction.csv")
forecastPrediction$month.Format <- as.factor(forecastPrediction$month.Format)
forecastPrediction$day.Format <- as.factor(forecastPrediction$day.Format)
forecastPrediction$`Day of Week`<- as.factor(forecastPrediction$`Day of Week`)
forecastPrediction$hour<- as.factor(forecastPrediction$hour)

names(matWeatherFinal)
names(forecastPrediction)
forecastPrediction <- forecastPrediction[,-1]

names(forecastPrediction) <- c("Date","hour","Temperature","Dew_PointF","Humidity","Sea_Level_PressureIn","VisibilityMPH","Wind_SpeedMPH","WindDirDegrees","Wind_Direction","Conditions","month","year","day","Day of Week","Weekday","Peakhour")
forecastPrediction <- forecastPrediction[,c("Date","month","day","year","hour","Day of Week","Weekday","Peakhour","Temperature","Dew_PointF","Humidity","Sea_Level_PressureIn","VisibilityMPH","Wind_Direction","Wind_SpeedMPH","Conditions","WindDirDegrees")]

names(matWeatherFinal) <- c("hour","Date","month","day","year","Day of Week","Weekday","Peakhour","kWh","Wind_Direction","Conditions","Temperature","Dew_PointF","Humidity","Sea_Level_PressureIn","VisibilityMPH","Wind_SpeedMPH","WindDirDegrees")
matWeatherFinal <- matWeatherFinal[,c("Date","kWh","month","day","year","hour","Day of Week","Weekday","Peakhour","Temperature","Dew_PointF","Humidity","Sea_Level_PressureIn","VisibilityMPH","Wind_Direction","Wind_SpeedMPH","Conditions","WindDirDegrees")]

View(matWeatherFinal)
View(forecastPrediction)

