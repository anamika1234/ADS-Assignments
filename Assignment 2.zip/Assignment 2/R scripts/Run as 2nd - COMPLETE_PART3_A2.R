fData <- read.csv('forecastData.csv', header=TRUE)
fInput <- read.csv('forecastInput.csv', header=TRUE)

View(fData)
View(fInput)

Date1 <- as.POSIXct(fData$Time)
hourForecast <- as.numeric(format(Date1, "%H"))


#install.packages("devtools")
#install.packages("dplyr")
library("dplyr")
library("devtools")


fData$hour <- hourForecast
nrow(fData)
length(hourForecast)
DateFormatting <- as.Date(fData$Time)
DateFormatting
fData$Date.Format <- DateFormatting

fData$Wind_Direction <- as.character(fData$Wind_Direction)
fData$Wind_SpeedMPH <- as.numeric(fData$Wind_SpeedMPH)
fData$Conditions <- as.character(fData$Conditions)
str(fData)
fDataNew = fData %>% group_by(Date.Format,hour) %>% summarize(Temperature = mean(TemperatureF), 
                                                      Dew_PointF = mean(Dew_PointF), 
                                                      Humidity = mean(Humidity), 
                                                      Sea_Level_PressureIn = mean(Sea_Level_PressureIn), 
                                                      VisibilityMPH = mean(VisibilityMPH), 
                                                      Wind_SpeedMPH = mean(Wind_SpeedMPH), 
                                                      WindDirDegrees = mean(WindDirDegrees), 
                                                      Wind_Direction = max(Wind_Direction),
                                                      
                                                      
                                                      Conditions = max(Conditions))



#Extracting month, year and date
fDataNew$month.Format <- format(fDataNew$Date.Format, "%m")
fDataNew$year.Format <- format(fDataNew$Date.Format, "%Y")
fDataNew$day.Format <- format(fDataNew$Date.Format, "%d")
#fDataNew$weekday.Format <-weekdays(fDataNew$Date.Format)
fDataNew$DayOfWeek.Format <-weekdays(as.POSIXlt(fDataNew$Date.Format))

dayofWeek_ <- (as.POSIXlt(fDataNew$Date.Format))
dayofWeek_ <- dayofWeek_$wday
fDataNew$DayOfWeek.Format<-dayofWeek_
View(fDataNew)


library(chron)
isWeekend <- chron::is.weekend(fDataNew$Date.Format)
Weekday.Format <- 1* (!isWeekend) # Converting logical to Binary
fDataNew$weekdayOrWeekend.Format<-Weekday.Format
fDataNew$peakOfhour_ <-ifelse(fDataNew$hour>=7 & fDataNew$hour<19,1,0)

View(fDataNew)
write.csv(fDataNew, file="forecastPrediction.csv")
