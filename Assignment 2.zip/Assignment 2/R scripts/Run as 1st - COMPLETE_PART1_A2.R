rawData.1 <- read.csv('rawData1.csv',header = TRUE)
rawData.2 <- read.csv('rawData2.csv',header = TRUE)
rawData.Final <- rbind(rawData.1,rawData.2)

powerUsage.05 <- vector(mode='numeric', length = 0)
firstHalf <- vector(mode='numeric', length = 0)
secondHalf <- vector(mode='numeric', length = 0)
powerFactor <- vector(mode='numeric', length = 0)

testData <- rawData.Final
#testData <- rawData.Final[8:14,]

#rowlength<-1
i<-0
colvalue <-5
finalPower <- data.frame('123',1:365)

while(colvalue <= ncol(testData)){
  rowlength<-1
  powerUsage.05 <- vector(mode='numeric', length = 0)
  while(rowlength<=nrow(testData)){
    
    if(as.character(testData$Units)[rowlength] == 'kWh' ){
      firstHalf <- c(firstHalf,as.numeric(testData[rowlength,colvalue]))
    } else if(as.character(testData$Units)[rowlength] == 'Power Factor' ){
      powerFactor <- as.numeric(testData[rowlength,colvalue])
    } else if(as.character(testData$Units)[rowlength] == 'kVARh' ){
      secondHalf <- c(secondHalf,as.numeric(testData[rowlength,colvalue]))
    }
    
    
    
    rowlength <- rowlength +1
    i<-i+1
    if(i %% 7 == 0){
      powerUsage.05 <- c(powerUsage.05,sum(firstHalf,(secondHalf * powerFactor)))
      firstHalf <- vector(mode='numeric', length = 0)
      secondHalf <- vector(mode='numeric', length = 0)
      powerFactor <- vector(mode='numeric', length = 0)
    }
    
    
  }
  
  colvalue <- colvalue +1
  
  finalPower <- cbind(finalPower, as.data.frame(powerUsage.05))
  
}



finalPowerMatrix <- as.matrix(finalPower[,c(3:ncol(finalPower))])
counterForClock <- 1
myDataFrame <- NULL
hourStart <- 1

while(counterForClock <= 288)
{
  summedUp <- rowSums(finalPowerMatrix[,hourStart:(hourStart+11)])
  hourStart <- hourStart + 12
  counterForClock <- counterForClock +12
  myDataFrame <- cbind(myDataFrame,summedUp)
}


myNewDataFrame <- t(myDataFrame)
power_ <-as.numeric(c(myNewDataFrame))
#View(as.data.frame(power_))

################ Date logic ############################
Date <- unique(rawData.Final$Date)
head(Date)
str(Date_)
head(Date_)

#converting factor to Date format
Date_ <- as.Date(Date,format = "%m/%d/%Y")
Date__ <- as.POSIXlt(Date_)

#Extracting month, year and date
month_ <- format(Date__, "%m")
year_ <- format(Date__, "%Y")
day_ <- format(Date__, "%d")
weekday_ <-weekdays(Date__)
dayofWeek_ <- Date__$wday

#install.packages("chron")
library(chron)
isWeekend <- chron::is.weekend(Date__)
#isWeekend <- 1*isWeekend
Weekday_ <- 1* (!isWeekend) # Converting logical to Binary
Weekday_

weather1 <- cbind(month_, day_, year_, dayofWeek_, Weekday_)


hour__ <- rep(0:23, 365)
Datee <- rep(Date_, each=24)
Datee <- as.Date(Datee,format = "%m-%d-%Y")
matWeatherDate_ <- Datee
Datee <- as.data.frame(matWeatherDate_)

#class(Datee)
#str(Datee)
#print(Datee[1])
#Date1 <- as.POSIXlt(Datee)

month__ <- as.integer(rep(month_, each=24))
year__ <- as.integer(rep(year_, each=24))
day__ <- as.integer(rep(day_, each=24))
weekday__ <- as.integer(rep(weekday_, each=24))
dayofWeek__ <- as.integer(rep(dayofWeek_, each=24))
Weekday__ <- as.integer(rep(Weekday_, each=24))


peakOfHour_ <- ifelse(hour__<=7 & hour__<19,1,0)

weather2 <- cbind(month__, day__, year__, dayofWeek__, Weekday__, hour__,peakOfHour_, Datee["matWeatherDate_"])
weatherPowerKwh <- cbind(weather2,power_)
View(weatherPowerKwh)
#is.data.frame(weatherPowerKwh)
weatherPowerKwhh <- as.data.frame(weatherPowerKwh)

########## getting wunderground data ######################

install.packages("devtools")
install.packages("dplyr")
library("dplyr")
library("devtools")
install_github("Ram-N/weatherData")
library(weatherData)

matWeather <- getWeatherForDate("KBOS", start_date = "2014-01-01",end_date = "2014-12-31", opt_custom_columns=TRUE, opt_detailed=TRUE,custom_columns=c(2,3,4,5,6,7,8,12,13),opt_all_columns=T)
#View(matWeather)
#str(matWeather)
###hour of day###
hour__ <- as.numeric(format(matWeather$Time, "%H"))
minute__ <- as.numeric(format(matWeather$Time, "%M"))

matWeatherDate_ <- as.Date(matWeather$Time,format = "%m/%d/%Y",tz='EST5EDT')
#str(matWeatherDate_)
matWeather <- cbind(matWeather,matWeatherDate_)
matWeather <- cbind(matWeather,hour__) 

#dfData <- ifelse(lead(minute__) - minute__ >0,lead(minute__) - minute__,60- minute__)
#matWeather <- cbind(matWeather,minute__)
#write.csv(matWeather, file = "notgrouped.csv")

matWeather$Wind_SpeedMPH <- ifelse(matWeather$Wind_SpeedMPH == "calm", 0, as.numeric(matWeather$Wind_SpeedMPH))
matWeather$Humidity <- ifelse(matWeather$Humidity == "N/A", 0, as.numeric(matWeather$Humidity))
#matWeather$Wind_Direction <- ifelse(matWeather$Wind_Direction == "calm", 0, as.numeric(matWeather$Wind_Direction))
matWeather$Wind_Direction <- gsub("Calm", "NA", matWeather$Wind_Direction)
#,Conditions
#matWeather,matWeatherDate_,hour_,Wind_Direction,Conditions
matWeather1 <- group_by(matWeather,matWeatherDate_,hour__) %>% 
  #filter(minute__ == max(minute__))  %>%
  summarise(Wind_Direction = as.factor(first(Wind_Direction)), Conditions = as.factor(first(Conditions)), Temperature = mean(TemperatureF),Dew_PointF = mean(Dew_PointF),
            Humidity = mean(Humidity,na.rm=TRUE), Sea_Level_PressureIn = mean(Sea_Level_PressureIn),
            VisibilityMPH = mean(VisibilityMPH),Wind_SpeedMPH = mean(Wind_SpeedMPH,na.rm=TRUE), WindDirDegrees = mean(WindDirDegrees)
  )
matWeather2 <- data.frame(matWeather1)
#peakOfhour_ <-ifelse(matWeather2$hour__>=7 & matWeather2$hour__<19,1,0)
#matWeather2 <- cbind(matWeather2,peakOfhour_)
#str(matWeather1)
#write.csv(matWeather, file = "grouped.csv")
#View(matWeather2)
#View(matWeather1)
#View(matWeather)


################### Merging both scripts ###################
matWeatherFinal <- merge(weatherPowerKwhh, matWeather2, by= c("hour__","matWeatherDate_"), all.x =TRUE)
#View(matWeatherFinal)
#write.csv(matWeatherFinal, file = "Sample Output.csv")
#str(matWeatherFinal)

matWeatherFinal$hour__<- as.factor(matWeatherFinal$hour__)
matWeatherFinal$Weekday__ <- as.factor(matWeatherFinal$Weekday__)
matWeatherFinal$dayofWeek__ <- as.factor(matWeatherFinal$dayofWeek__)
matWeatherFinal$year__<- as.numeric(matWeatherFinal$year__)
matWeatherFinal$month__ <- as.factor(matWeatherFinal$month__)
matWeatherFinal$peakOfHour_ <- as.factor(matWeatherFinal$peakOfHour_)
matWeatherFinal$day__ <- as.factor(matWeatherFinal$day__)
matWeatherFinal <- matWeatherFinal[,-19]
View(matWeatherFinal)
#apply(matWeatherFinal, 2, function(x) any(is.na(x)))


################################ MODELLING ################################################



